<?php /* Smarty version Smarty-3.0.6, created on 2011-12-08 11:36:32
         compiled from "./templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4263408704edd927190c2e0-02851894%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a4f6f0d327fc7bc3ea86f63906a1bf934ca50c7' => 
    array (
      0 => './templates/footer.tpl',
      1 => 1323315386,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4263408704edd927190c2e0-02851894',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
</body>
</html>