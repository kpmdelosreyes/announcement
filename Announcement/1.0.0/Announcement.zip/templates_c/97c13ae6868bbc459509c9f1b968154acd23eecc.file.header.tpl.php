<?php /* Smarty version Smarty-3.0.6, created on 2011-12-08 11:36:32
         compiled from "./templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19109115924edef5aa56fc72-27924767%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '97c13ae6868bbc459509c9f1b968154acd23eecc' => 
    array (
      0 => './templates/header.tpl',
      1 => 1323315386,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19109115924edef5aa56fc72-27924767',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <title>Announcement</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
       
        <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->getVariable('sPgDir')->value;?>
css/common.css" />
        <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->getVariable('sPgDir')->value;?>
css/front.css" />
    
        <script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('jquery')->value;?>
"></script>
        <script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('emulation')->value;?>
"></script>
        <script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sPgDir')->value;?>
js/timeago.js"></script>
        <script type="text/javascript" src="<?php echo $_smarty_tpl->getVariable('sPgDir')->value;?>
js/announcement.front.js"></script>

	<!--[if IE 8]>
	<link href="<?php echo $_smarty_tpl->getVariable('sPgDir')->value;?>
css/ie8.css" rel="stylesheet" type="text/css" media="screen" />	
	<![endif]-->
	<!--[if IE 7]>
	<link href="<?php echo $_smarty_tpl->getVariable('sPgDir')->value;?>
css/ie7.css" rel="stylesheet" type="text/css" media="screen" />	
	<![endif]-->
	<!--[if lte IE 7]>
	<link href="<?php echo $_smarty_tpl->getVariable('sPgDir')->value;?>
css/lte_ie7.css" rel="stylesheet" type="text/css" media="screen" />
	<script defer type="text/javascript" language="Javascript" src="<?php echo $_smarty_tpl->getVariable('sPgDir')->value;?>
js/pngfix.js"></script>
	<![endif]-->
	<!--[if IE 6]>
	<link href="<?php echo $_smarty_tpl->getVariable('sPgDir')->value;?>
css/ie6.css" rel="stylesheet" type="text/css" media="screen" />	
	<![endif]-->

</head>
<body id="PLUGIN_Announcement"  >
