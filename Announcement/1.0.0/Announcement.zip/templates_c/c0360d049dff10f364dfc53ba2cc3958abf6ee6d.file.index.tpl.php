<?php /* Smarty version Smarty-3.0.6, created on 2011-12-08 11:36:32
         compiled from "./templates/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3198181844ecd8969ddde59-16294476%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c0360d049dff10f364dfc53ba2cc3958abf6ee6d' => 
    array (
      0 => './templates/index.tpl',
      1 => 1323315386,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3198181844ecd8969ddde59-16294476',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php echo $_smarty_tpl->getVariable('template_top')->value;?>

<?php echo $_smarty_tpl->getVariable('template_contents')->value;?>

<?php echo $_smarty_tpl->getVariable('template_bottom')->value;?>
